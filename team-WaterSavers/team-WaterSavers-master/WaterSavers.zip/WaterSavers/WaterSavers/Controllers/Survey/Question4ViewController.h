//
//  Question4ViewController.h
//  WaterSavers
//
//  Created by Utsav Parikh on 10/7/15.
//  Copyright © 2015 HackathonSDSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Question4ViewController : UIViewController
{
    NSArray *pickerData;
    IBOutlet UIPickerView *picker;
}

@end
