//
//  RegisterCell.m
//  WaterSavers
//
//  Created by Utsav Parikh on 10/4/15.
//  Copyright © 2015 HackathonSDSU. All rights reserved.
//

#import "RegisterCell.h"

@implementation RegisterCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
