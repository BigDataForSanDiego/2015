//
//  RegisterCell.h
//  WaterSavers
//
//  Created by Utsav Parikh on 10/4/15.
//  Copyright © 2015 HackathonSDSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UITextField *txtValues;

@end
