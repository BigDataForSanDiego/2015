//
//  TipsViewController.h
//  WaterSavers
//
//  Created by Utsav Parikh on 10/7/15.
//  Copyright © 2015 HackathonSDSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TipsViewController : UIViewController
{
    IBOutlet UILabel *lblNoData;
    IBOutlet UITableView *tblTips;
}


@end
